class Item(object):
    image1 = loadImage("PImage0.png")
    x = 0
    y = 0

    def __init__(self, name, imageName, x, y):
        self.name = name
        self.imageName = imageName
        Lamp = loadImage(imageName)
        
        self.x = x
        self.y = y

    def display(self, img):
        n = image(img, 75, 75)
#LAMPPOST

#WATERTANK

#PHOTOBOOTH

#HOT COCOA CART

#SNOW CONE CART
